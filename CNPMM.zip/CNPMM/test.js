import 'dotenv/config';
import connectDB from './src/db.js';
import User from './src/models/user.js';

(async () => {
  await connectDB();

  // XÓA HẾT USER CŨ (để test sạch)
  await User.deleteMany({});
  console.log('Đã xóa user cũ');

  // TẠO USER MỚI
  const user = await User.create({
    name: 'Thanh LT',
    email: 'thanhlt@gmail.com',
    password: '123456'
  });
  console.log('User mới:', user);

  // HIỆN TẤT CẢ
  const all = await User.find();
  console.log('Tất cả user:', all);
})();