
import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  address: { type: String, required: true },
  phoneNumber: { type: String, required: true },
  gender: { type: Boolean, required: true },
  image: { type: String },
  roleId: { type: String, required: true },
  positionId: { type: String }
}, { timestamps: true });

export default mongoose.model('User', userSchema);