import express from 'express';

let configureViewEngine = (app) => {
    app.use(express.static('./src/public')); // thiet lap thu muc chua file static

    app.set("view engine", "ejs"); // thiet lap ejs lam view engine
    app.set("views", "./src/views"); // thiet lap thu muc chua file view
}

module.exports = configureViewEngine; // xuat