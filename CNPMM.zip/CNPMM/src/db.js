// src/db.js
import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URL);
    console.log('🚀 MongoDB kết nối thành công!');
  } catch (err) {
    console.log('💥 Kết nối thất bại:', err.message);
    process.exit(1);
  }
};

export default connectDB;